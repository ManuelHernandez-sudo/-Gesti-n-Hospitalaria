# Backend - Sistema de Gestión Hospitalaria (MVP)

FastAPI + SQLAlchemy + SQLite (por defecto, cero configuración).

## Arrancar en 3 pasos

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Abre **http://127.0.0.1:8000/docs** — ahí puedes probar todos los endpoints desde el navegador (Swagger UI) sin necesitar el frontend.

## Módulos incluidos (MVP)

- `/api/pacientes` — CRUD completo
- `/api/medicos` y `/api/especialidades` — CRUD básico
- `/api/citas` — crear, listar, cambiar estado, cancelar (valida choque de horario)
- `/api/historial` — obtener historial por paciente, registrar consultas con diagnósticos

## Cambiar a PostgreSQL (opcional, si te sobra tiempo)

En `app/core/config.py` cambia `DATABASE_URL` a algo como:
```
postgresql://usuario:password@localhost:5432/hospital_db
```
E instala el driver: `pip install psycopg2-binary`

## Flujo típico para probar

1. Crear una especialidad → `POST /api/especialidades`
2. Crear un médico con esa especialidad → `POST /api/medicos`
3. Crear un paciente → `POST /api/pacientes`
4. Crear una cita → `POST /api/citas`
5. Obtener/crear el historial del paciente → `GET /api/historial/paciente/{id}`
6. Registrar una consulta con diagnóstico → `POST /api/historial/consultas`
