from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.models.clinico import Cita
from app.models.pacientes_medicos import Paciente, Medico
from app.schemas.clinico import CitaCreate, CitaOut

router = APIRouter(prefix="/api/citas", tags=["Citas"])


@router.get("/", response_model=List[CitaOut])
def listar_citas(paciente_id: int | None = None, db: Session = Depends(get_db)):
    query = db.query(Cita)
    if paciente_id:
        query = query.filter(Cita.paciente_id == paciente_id)
    return query.order_by(Cita.fecha_hora).all()


@router.post("/", response_model=CitaOut, status_code=201)
def crear_cita(cita: CitaCreate, db: Session = Depends(get_db)):
    if not db.query(Paciente).filter(Paciente.id == cita.paciente_id).first():
        raise HTTPException(status_code=404, detail="Paciente no existe")
    if not db.query(Medico).filter(Medico.id == cita.medico_id).first():
        raise HTTPException(status_code=404, detail="Médico no existe")

    # RN-01: un paciente no puede tener dos citas activas con el mismo médico en el mismo horario
    conflicto = db.query(Cita).filter(
        Cita.paciente_id == cita.paciente_id,
        Cita.medico_id == cita.medico_id,
        Cita.fecha_hora == cita.fecha_hora,
        Cita.estado != "cancelada",
    ).first()
    if conflicto:
        raise HTTPException(status_code=400, detail="Ya existe una cita en ese horario con ese médico")

    nueva = Cita(**cita.model_dump())
    db.add(nueva)
    db.commit()
    db.refresh(nueva)
    return nueva


@router.put("/{cita_id}/estado", response_model=CitaOut)
def cambiar_estado_cita(cita_id: int, estado: str, db: Session = Depends(get_db)):
    cita = db.query(Cita).filter(Cita.id == cita_id).first()
    if not cita:
        raise HTTPException(status_code=404, detail="Cita no encontrada")
    cita.estado = estado
    db.commit()
    db.refresh(cita)
    return cita


@router.delete("/{cita_id}", status_code=204)
def cancelar_cita(cita_id: int, db: Session = Depends(get_db)):
    cita = db.query(Cita).filter(Cita.id == cita_id).first()
    if not cita:
        raise HTTPException(status_code=404, detail="Cita no encontrada")
    cita.estado = "cancelada"
    db.commit()
    return None
