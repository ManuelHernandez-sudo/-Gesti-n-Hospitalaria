from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.clinico import HistorialClinico, Consulta, Diagnostico
from app.models.pacientes_medicos import Paciente
from app.schemas.clinico import ConsultaCreate, ConsultaOut, HistorialOut

router = APIRouter(prefix="/api/historial", tags=["Historial Clinico"])


@router.get("/paciente/{paciente_id}", response_model=HistorialOut)
def obtener_historial(paciente_id: int, db: Session = Depends(get_db)):
    historial = db.query(HistorialClinico).filter(
        HistorialClinico.paciente_id == paciente_id
    ).first()

    # RF-05/06: si el paciente no tiene historial, se crea automáticamente en su primera consulta
    if not historial:
        paciente = db.query(Paciente).filter(Paciente.id == paciente_id).first()
        if not paciente:
            raise HTTPException(status_code=404, detail="Paciente no encontrado")
        historial = HistorialClinico(paciente_id=paciente_id, fecha_creacion=date.today())
        db.add(historial)
        db.commit()
        db.refresh(historial)

    return historial


@router.post("/consultas", response_model=ConsultaOut, status_code=201)
def crear_consulta(consulta: ConsultaCreate, db: Session = Depends(get_db)):
    historial = db.query(HistorialClinico).filter(
        HistorialClinico.id == consulta.historial_id
    ).first()
    if not historial:
        raise HTTPException(status_code=404, detail="Historial clínico no encontrado")

    datos = consulta.model_dump(exclude={"diagnosticos"})
    nueva_consulta = Consulta(**datos)
    db.add(nueva_consulta)
    db.commit()
    db.refresh(nueva_consulta)

    for diag in consulta.diagnosticos or []:
        db.add(Diagnostico(consulta_id=nueva_consulta.id, **diag.model_dump()))
    db.commit()
    db.refresh(nueva_consulta)

    return nueva_consulta
