from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.models.pacientes_medicos import Medico, Especialidad
from app.schemas.pacientes_medicos import MedicoCreate, MedicoOut, EspecialidadOut

router = APIRouter(prefix="/api/medicos", tags=["Medicos"])


@router.get("/", response_model=List[MedicoOut])
def listar_medicos(db: Session = Depends(get_db)):
    return db.query(Medico).all()


@router.post("/", response_model=MedicoOut, status_code=201)
def crear_medico(medico: MedicoCreate, db: Session = Depends(get_db)):
    nuevo = Medico(**medico.model_dump())
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return nuevo


@router.get("/{medico_id}", response_model=MedicoOut)
def obtener_medico(medico_id: int, db: Session = Depends(get_db)):
    medico = db.query(Medico).filter(Medico.id == medico_id).first()
    if not medico:
        raise HTTPException(status_code=404, detail="Médico no encontrado")
    return medico


especialidades_router = APIRouter(prefix="/api/especialidades", tags=["Especialidades"])


@especialidades_router.get("/", response_model=List[EspecialidadOut])
def listar_especialidades(db: Session = Depends(get_db)):
    return db.query(Especialidad).all()


@especialidades_router.post("/", response_model=EspecialidadOut, status_code=201)
def crear_especialidad(nombre: str, descripcion: str = "", db: Session = Depends(get_db)):
    nueva = Especialidad(nombre=nombre, descripcion=descripcion)
    db.add(nueva)
    db.commit()
    db.refresh(nueva)
    return nueva
