from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.models.pacientes_medicos import Paciente
from app.schemas.pacientes_medicos import PacienteCreate, PacienteUpdate, PacienteOut

router = APIRouter(prefix="/api/pacientes", tags=["Pacientes"])


@router.get("/", response_model=List[PacienteOut])
def listar_pacientes(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(Paciente).offset(skip).limit(limit).all()


@router.get("/{paciente_id}", response_model=PacienteOut)
def obtener_paciente(paciente_id: int, db: Session = Depends(get_db)):
    paciente = db.query(Paciente).filter(Paciente.id == paciente_id).first()
    if not paciente:
        raise HTTPException(status_code=404, detail="Paciente no encontrado")
    return paciente


@router.post("/", response_model=PacienteOut, status_code=201)
def crear_paciente(paciente: PacienteCreate, db: Session = Depends(get_db)):
    if paciente.cui:
        existente = db.query(Paciente).filter(Paciente.cui == paciente.cui).first()
        if existente:
            raise HTTPException(status_code=400, detail="Ya existe un paciente con ese CUI")
    nuevo = Paciente(**paciente.model_dump())
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return nuevo


@router.put("/{paciente_id}", response_model=PacienteOut)
def actualizar_paciente(paciente_id: int, datos: PacienteUpdate, db: Session = Depends(get_db)):
    paciente = db.query(Paciente).filter(Paciente.id == paciente_id).first()
    if not paciente:
        raise HTTPException(status_code=404, detail="Paciente no encontrado")
    for campo, valor in datos.model_dump().items():
        setattr(paciente, campo, valor)
    db.commit()
    db.refresh(paciente)
    return paciente


@router.delete("/{paciente_id}", status_code=204)
def eliminar_paciente(paciente_id: int, db: Session = Depends(get_db)):
    paciente = db.query(Paciente).filter(Paciente.id == paciente_id).first()
    if not paciente:
        raise HTTPException(status_code=404, detail="Paciente no encontrado")
    db.delete(paciente)
    db.commit()
    return None
