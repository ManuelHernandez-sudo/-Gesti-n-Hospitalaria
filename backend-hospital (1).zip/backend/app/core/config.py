import os

# Para el MVP de 24h usamos SQLite por defecto (cero configuración).
# Si tienes PostgreSQL listo, cambia esta variable de entorno o el valor por defecto:
# postgresql://usuario:password@localhost:5432/hospital_db
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./hospital.db")

CORS_ORIGINS = [
    "http://localhost:4200",  # Angular dev server
]
