from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import Base, engine
from app.core.config import CORS_ORIGINS
from app import models  # noqa: F401 - asegura que todos los modelos se registren antes de create_all

from app.api.pacientes import router as pacientes_router
from app.api.medicos import router as medicos_router, especialidades_router
from app.api.citas import router as citas_router
from app.api.historial import router as historial_router

app = FastAPI(
    title="API - Sistema de Gestión Hospitalaria",
    description="MVP: Pacientes, Citas e Historial Clínico",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Crea las tablas si no existen (suficiente para el MVP de 24h; usar Alembic en producción)
Base.metadata.create_all(bind=engine)

app.include_router(pacientes_router)
app.include_router(medicos_router)
app.include_router(especialidades_router)
app.include_router(citas_router)
app.include_router(historial_router)


@app.get("/")
def root():
    return {"status": "ok", "docs": "/docs"}
