from app.core.database import Base
from app.models.pacientes_medicos import Paciente, Medico, Especialidad
from app.models.clinico import Cita, HistorialClinico, Consulta, Diagnostico

__all__ = [
    "Base",
    "Paciente",
    "Medico",
    "Especialidad",
    "Cita",
    "HistorialClinico",
    "Consulta",
    "Diagnostico",
]
