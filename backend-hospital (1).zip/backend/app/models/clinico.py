from sqlalchemy import Column, Integer, String, DateTime, Date, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.database import Base


class Cita(Base):
    __tablename__ = "citas"

    id = Column(Integer, primary_key=True, index=True)
    paciente_id = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    medico_id = Column(Integer, ForeignKey("medicos.id"), nullable=False)
    fecha_hora = Column(DateTime, nullable=False)
    estado = Column(String(30), default="pendiente")  # pendiente, confirmada, cancelada, atendida
    motivo = Column(String(255))

    paciente = relationship("Paciente", back_populates="citas")
    medico = relationship("Medico", back_populates="citas")
    consulta = relationship("Consulta", back_populates="cita", uselist=False)


class HistorialClinico(Base):
    __tablename__ = "historiales_clinicos"

    id = Column(Integer, primary_key=True, index=True)
    paciente_id = Column(Integer, ForeignKey("pacientes.id"), unique=True, nullable=False)
    fecha_creacion = Column(Date, nullable=False)

    paciente = relationship("Paciente", back_populates="historial")
    consultas = relationship("Consulta", back_populates="historial")


class Consulta(Base):
    __tablename__ = "consultas"

    id = Column(Integer, primary_key=True, index=True)
    cita_id = Column(Integer, ForeignKey("citas.id"), unique=True)
    historial_id = Column(Integer, ForeignKey("historiales_clinicos.id"), nullable=False)
    fecha = Column(Date, nullable=False)
    notas = Column(Text)

    cita = relationship("Cita", back_populates="consulta")
    historial = relationship("HistorialClinico", back_populates="consultas")
    diagnosticos = relationship("Diagnostico", back_populates="consulta")


class Diagnostico(Base):
    __tablename__ = "diagnosticos"

    id = Column(Integer, primary_key=True, index=True)
    consulta_id = Column(Integer, ForeignKey("consultas.id"), nullable=False)
    codigo_cie10 = Column(String(10))
    descripcion = Column(String(255), nullable=False)

    consulta = relationship("Consulta", back_populates="diagnosticos")
