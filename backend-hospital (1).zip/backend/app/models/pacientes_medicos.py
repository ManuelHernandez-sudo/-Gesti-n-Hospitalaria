from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base


class Especialidad(Base):
    __tablename__ = "especialidades"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(String(255))

    medicos = relationship("Medico", back_populates="especialidad")


class Medico(Base):
    __tablename__ = "medicos"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    apellido = Column(String(100), nullable=False)
    especialidad_id = Column(Integer, ForeignKey("especialidades.id"))
    num_colegiado = Column(String(50))
    telefono = Column(String(30))

    especialidad = relationship("Especialidad", back_populates="medicos")
    citas = relationship("Cita", back_populates="medico")


class Paciente(Base):
    __tablename__ = "pacientes"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    apellido = Column(String(100), nullable=False)
    fecha_nacimiento = Column(Date, nullable=False)
    genero = Column(String(20))
    cui = Column(String(20), unique=True, index=True)
    telefono = Column(String(30))
    email = Column(String(100))
    tipo_sangre = Column(String(5))

    citas = relationship("Cita", back_populates="paciente")
    historial = relationship("HistorialClinico", back_populates="paciente", uselist=False)
