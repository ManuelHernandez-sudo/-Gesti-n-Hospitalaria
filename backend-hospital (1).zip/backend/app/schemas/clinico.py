from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


class CitaBase(BaseModel):
    paciente_id: int
    medico_id: int
    fecha_hora: datetime
    estado: Optional[str] = "pendiente"
    motivo: Optional[str] = None


class CitaCreate(CitaBase):
    pass


class CitaOut(CitaBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class DiagnosticoBase(BaseModel):
    codigo_cie10: Optional[str] = None
    descripcion: str


class DiagnosticoCreate(DiagnosticoBase):
    pass


class DiagnosticoOut(DiagnosticoBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    consulta_id: int


class ConsultaBase(BaseModel):
    cita_id: Optional[int] = None
    historial_id: int
    fecha: date
    notas: Optional[str] = None


class ConsultaCreate(ConsultaBase):
    diagnosticos: Optional[List[DiagnosticoCreate]] = []


class ConsultaOut(ConsultaBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    diagnosticos: List[DiagnosticoOut] = []


class HistorialOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    paciente_id: int
    fecha_creacion: date
    consultas: List[ConsultaOut] = []
