from datetime import date
from typing import Optional
from pydantic import BaseModel, ConfigDict


class PacienteBase(BaseModel):
    nombre: str
    apellido: str
    fecha_nacimiento: date
    genero: Optional[str] = None
    cui: Optional[str] = None
    telefono: Optional[str] = None
    email: Optional[str] = None
    tipo_sangre: Optional[str] = None


class PacienteCreate(PacienteBase):
    pass


class PacienteUpdate(PacienteBase):
    pass


class PacienteOut(PacienteBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class EspecialidadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    nombre: str
    descripcion: Optional[str] = None


class MedicoBase(BaseModel):
    nombre: str
    apellido: str
    especialidad_id: Optional[int] = None
    num_colegiado: Optional[str] = None
    telefono: Optional[str] = None


class MedicoCreate(MedicoBase):
    pass


class MedicoOut(MedicoBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
